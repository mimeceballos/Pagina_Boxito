<footer class="w3-container w3-padding-32 w3-center" style="background-color: #022336; color: white; font-weight: bold;">

  <img src="assets/imagenes/logo.png" class="w3-image w3-greyscale-min" style="width:10%;">
  <h2>Contáctanos</h2>
  <h3>800 002 6948</h3>
  <h3>tienda@boxito.com.mx</h3>
  <h3>Calle 96 #892 Edif. A, int. 101, entre 99 y 107</h3>
  
  <div style="position:relative;bottom:100px;z-index:1;" class="w3-tooltip w3-right">   
    <a class="w3-button w3-theme" href="#myPage"><span class="w3-xlarge">
    <i class="fa fa-chevron-circle-up"></i></span></a>
  </div>
</footer>
