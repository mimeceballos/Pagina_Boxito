<!DOCTYPE html>
<html>
<head>
<title>BOXITO</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
.tarjeta h1 {
    font-size: 18px;
    color: #022336;
    margin: 10px 0;
    font-weight: bold;
}

.tarjeta h2 {
    font-size: 14px;
    color: #666;
    margin: 8px 0;
    font-weight: bold;
}

.tarjeta p {
    font-size: 12px;
    color: #777;
    margin: 6px 0;
    font-weight: normal;
}

.tarjeta i {
    font-size: 12px;
    color: #777;
    margin: 6px 0;
    font-weight: normal;
    font-style: italic;
}
</style>




</head>