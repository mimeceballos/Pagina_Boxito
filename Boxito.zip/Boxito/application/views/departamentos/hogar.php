<div class="w3-container w3-padding-64 w3-light-grey">
    <div class="w3-center w3-padding-16">
        <h1 style="color: #0F0E0E;"><b>HOGAR</b></h1>
    </div>
    
    <?php
    
    if(!empty($productos_hogar)): 
    ?>
    <div class="w3-row-padding w3-margin-top">
        <?php
        $categoria_anterior = '';
        foreach($productos_hogar as $producto): 
            if($categoria_anterior != $producto->clasificacion):
                $categoria_anterior = $producto->clasificacion;
        ?>
        
        <!-- TITULO -->
        <div class="w3-col s12 w3-margin-top">
            <h3 class="w3-panel"><?php echo $categoria_anterior; ?></h3>
        </div>
        
        <?php endif;?>
        
        <!-- PRODUCTO -->
        <div class="w3-col l4 m6 s12 w3-margin-bottom">
            <div class="w3-card-4 w3-padding w3-hover-shadow w3-round-large w3-white">
                <p><b><?php echo $producto->separacion; ?></b></p>
                <h4><?php echo $producto->producto; ?></h4>
            </div>
        </div>
        
        <?php endforeach; ?>
        
    </div>
    
    <?php
    endif;
    ?>
</div>