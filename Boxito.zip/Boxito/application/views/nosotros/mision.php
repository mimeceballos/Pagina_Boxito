<div class="w3-container w3-padding-64 w3-light-grey" id="nosotros">
<h1 style="color: #0F0E0E; margin-bottom: 8px;"><b><CENTER>MISIÓN</b></h1>