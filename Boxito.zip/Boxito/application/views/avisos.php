<div class="container-fluid">
    <div class="row">
        <div class="col-sm-6">
            <h1>PROCEDIMIENTO DE SOLICITUD DE INSTALACIONES FCA</h1>
            <p>Procedimiento de Solicitud de Espacios, Instalaciones, Mobiliario y Equipo</p>
        </div>
        <div class="col-sm-6">
            <h1>PROCEDIMIENTO DE SOLICITUD DE INSTALACIONES FCA</h1>
            <p>Procedimiento de Solicitud de Espacios, Instalaciones, Mobiliario y Equipo</p>
        </div>
    </div>
</div>
