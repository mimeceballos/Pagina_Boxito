<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-17 09:44:50 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][DBNETLIB]No existe el servidor SQL Server o se ha denegado el acceso al mismo., SQL state 08001 in SQLConnect C:\xampp\htdocs\Boxito\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-17 09:44:50 --> Unable to connect to the database
ERROR - 2025-10-17 09:48:04 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 12:42:38 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 12:43:04 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 12:45:45 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 13:03:04 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 13:03:09 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 20:54:53 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 20:55:07 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 20:55:22 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 21:29:42 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 23:04:52 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 23:09:39 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 23:09:50 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-17 23:12:16 --> 404 Page Not Found: Welcome/assets
