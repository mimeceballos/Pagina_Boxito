<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-09 22:08:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-09-09 22:26:55 --> Severity: error --> Exception: Call to undefined function convertir_status() C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\views\welcome_message.php 83
ERROR - 2025-09-09 22:28:40 --> Severity: error --> Exception: Call to undefined function convertir_status() C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\views\welcome_message.php 83
