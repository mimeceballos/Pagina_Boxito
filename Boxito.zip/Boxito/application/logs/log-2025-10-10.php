<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-10 04:54:11 --> Severity: error --> Exception: Call to undefined method Pagina_model::consultar_ferreteria() C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 34
ERROR - 2025-10-10 04:55:09 --> Severity: Warning --> Undefined variable $electricidad C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 241
ERROR - 2025-10-10 04:55:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 241
ERROR - 2025-10-10 05:11:39 --> 404 Page Not Found: Boxito/ba%C3%B1o
ERROR - 2025-10-10 05:11:52 --> 404 Page Not Found: Boxito/ba%C3%B1o
ERROR - 2025-10-10 05:11:57 --> 404 Page Not Found: Boxito/ba%C3%B1o
ERROR - 2025-10-10 05:12:23 --> 404 Page Not Found: Boxito/ba%C3%B1o
ERROR - 2025-10-10 05:12:27 --> 404 Page Not Found: Boxito/piso
ERROR - 2025-10-10 05:12:31 --> 404 Page Not Found: Boxito/cocina
