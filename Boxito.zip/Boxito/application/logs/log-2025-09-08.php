<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-08 19:49:48 --> Severity: error --> Exception: syntax error, unexpected token "&" C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 24
ERROR - 2025-09-08 19:50:17 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\views\welcome_message.php 74
ERROR - 2025-09-08 19:50:17 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\views\welcome_message.php 75
ERROR - 2025-09-08 19:50:52 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\views\welcome_message.php 74
ERROR - 2025-09-08 19:50:52 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\views\welcome_message.php 75
ERROR - 2025-09-08 21:05:24 --> Severity: error --> Exception: syntax error, unexpected identifier "public_function", expecting "function" or "const" C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 5
ERROR - 2025-09-08 21:41:24 --> Severity: error --> Exception: syntax error, unexpected token "&" C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\views\welcome_message.php 76
ERROR - 2025-09-08 21:41:43 --> Severity: error --> Exception: syntax error, unexpected token "}", expecting "," or ";" C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\views\welcome_message.php 84
ERROR - 2025-09-08 21:49:15 --> Severity: Warning --> Undefined property: Welcome::$Pagina_model C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 29
ERROR - 2025-09-08 21:49:15 --> Severity: error --> Exception: Call to a member function consultar_seccion() on null C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 29
ERROR - 2025-09-08 21:49:35 --> Severity: Warning --> Undefined property: Welcome::$model C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 29
ERROR - 2025-09-08 21:49:35 --> Severity: error --> Exception: Call to a member function consultar_seccion() on null C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 29
ERROR - 2025-09-08 21:51:06 --> Severity: error --> Exception: Call to undefined method Pagina_model::obtener_secciones() C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 29
ERROR - 2025-09-08 22:01:50 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting "function" or "const" C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 25
ERROR - 2025-09-08 22:02:18 --> Severity: Warning --> Undefined property: Welcome::$Pagina_model C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 29
ERROR - 2025-09-08 22:02:18 --> Severity: error --> Exception: Call to a member function consultar_seccion() on null C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\controllers\Welcome.php 29
ERROR - 2025-09-08 22:03:25 --> Severity: error --> Exception: Undefined constant "Pagina_model" C:\Users\karim\OneDrive\Escritorio\Laragon\www\EMPRESAA\application\config\autoload.php 129
