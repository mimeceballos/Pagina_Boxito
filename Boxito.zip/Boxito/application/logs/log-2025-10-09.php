<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-09 03:43:38 --> Severity: error --> Exception: Call to undefined method Pagina_model::consultar_seccion() C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 29
ERROR - 2025-10-09 03:45:35 --> Severity: Warning --> Undefined property: Welcome::$Contenido_model C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 35
ERROR - 2025-10-09 03:45:35 --> Severity: error --> Exception: Call to a member function get_contenido_por_seccion() on null C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 35
ERROR - 2025-10-09 03:46:29 --> Severity: Warning --> Undefined variable $id_seccion C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 35
ERROR - 2025-10-09 03:46:57 --> Severity: Warning --> Undefined variable $idseccion C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 35
ERROR - 2025-10-09 03:47:41 --> Severity: Warning --> Undefined variable $idcatseccion C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 35
ERROR - 2025-10-09 03:50:20 --> Severity: Warning --> Undefined variable $data C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 37
ERROR - 2025-10-09 03:56:15 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 33
ERROR - 2025-10-09 03:56:41 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 33
ERROR - 2025-10-09 03:56:59 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 40
ERROR - 2025-10-09 03:57:17 --> Severity: Compile Error --> Cannot redeclare Pagina_model::consultar_seccion() C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\models\Pagina_model.php 45
ERROR - 2025-10-09 03:57:55 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 03:57:55 --> Severity: 8192 --> utf8_decode(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 03:57:55 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 03:57:55 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 03:57:55 --> Severity: 8192 --> utf8_decode(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 03:57:55 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 03:57:55 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 03:57:55 --> Severity: 8192 --> utf8_decode(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 03:57:55 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 03:57:55 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 03:57:55 --> Severity: 8192 --> utf8_decode(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 03:57:55 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 03:58:57 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 33
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$Id C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$nombre_seccion C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$activo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 92
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$Id C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$nombre_seccion C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$activo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 92
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$Id C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$nombre_seccion C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$activo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 92
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$Id C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$nombre_seccion C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:00:17 --> Severity: Warning --> Undefined property: stdClass::$activo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 92
ERROR - 2025-10-09 04:01:22 --> Severity: error --> Exception: syntax error, unexpected token "." C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:01:36 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 04:01:36 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:01:36 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 04:01:36 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:01:36 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 04:01:36 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:01:36 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 04:01:36 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:02:10 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:02:10 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:02:10 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 04:02:10 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 06:47:37 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 06:54:07 --> Severity: error --> Exception: Call to undefined method Pagina_model::get_menu() C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 31
ERROR - 2025-10-09 06:54:53 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 06:57:03 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 06:57:38 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 06:58:34 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 06:59:30 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 07:02:12 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 07:02:40 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 07:07:08 --> 404 Page Not Found: Boxito/about
ERROR - 2025-10-09 07:07:16 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 07:27:45 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 93
ERROR - 2025-10-09 07:27:45 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 93
ERROR - 2025-10-09 07:27:45 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 93
ERROR - 2025-10-09 07:27:45 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 93
ERROR - 2025-10-09 07:27:45 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 07:29:52 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 86
ERROR - 2025-10-09 07:29:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 87
ERROR - 2025-10-09 07:29:52 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 86
ERROR - 2025-10-09 07:29:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 87
ERROR - 2025-10-09 07:29:52 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 86
ERROR - 2025-10-09 07:29:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 87
ERROR - 2025-10-09 07:29:52 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 86
ERROR - 2025-10-09 07:29:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 87
ERROR - 2025-10-09 07:29:52 --> 404 Page Not Found: Boxito/imagenes
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 90
ERROR - 2025-10-09 07:33:14 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 91
ERROR - 2025-10-09 07:34:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:34:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:34:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:34:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:34:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:34:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:34:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:34:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:34:52 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 89
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 07:39:54 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:43:19 --> Severity: Warning --> Undefined property: stdClass::$contenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 83
ERROR - 2025-10-09 15:53:01 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:53:01 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:53:01 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:53:01 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:53:01 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:53:01 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:53:01 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:53:01 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 15:53:01 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 16:01:58 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 16:01:59 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 16:01:59 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 16:01:59 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 16:01:59 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 16:01:59 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 16:01:59 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 16:01:59 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 16:01:59 --> Severity: Warning --> Undefined property: stdClass::$idcontenido C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 82
ERROR - 2025-10-09 17:27:00 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 100
ERROR - 2025-10-09 17:27:30 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 103
ERROR - 2025-10-09 17:29:53 --> Severity: Warning --> Undefined variable $nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 74
ERROR - 2025-10-09 17:29:53 --> Severity: Warning --> Undefined variable $correo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 75
ERROR - 2025-10-09 17:29:53 --> Severity: Warning --> Undefined variable $correo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 76
ERROR - 2025-10-09 17:39:24 --> Severity: Warning --> Undefined property: stdClass::$ruta C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 100
ERROR - 2025-10-09 17:39:24 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\core\Config.php 335
ERROR - 2025-10-09 17:39:24 --> Severity: Warning --> Undefined property: stdClass::$ruta C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 100
ERROR - 2025-10-09 17:40:32 --> Severity: Warning --> Undefined property: stdClass::$ruta C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 100
ERROR - 2025-10-09 17:40:32 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\core\Config.php 335
ERROR - 2025-10-09 17:40:32 --> Severity: Warning --> Undefined property: stdClass::$ruta C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 100
ERROR - 2025-10-09 17:44:08 --> Severity: Warning --> Undefined property: stdClass::$ruta C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 100
ERROR - 2025-10-09 17:44:08 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\core\Config.php 335
ERROR - 2025-10-09 17:44:08 --> Severity: Warning --> Undefined property: stdClass::$ruta C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 100
ERROR - 2025-10-09 17:55:51 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 103
ERROR - 2025-10-09 17:56:19 --> Severity: error --> Exception: syntax error, unexpected end of file C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 120
ERROR - 2025-10-09 17:56:39 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 100
ERROR - 2025-10-09 17:58:19 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 101
ERROR - 2025-10-09 17:58:36 --> Severity: error --> Exception: syntax error, unexpected identifier "src" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 101
ERROR - 2025-10-09 19:43:22 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 101
ERROR - 2025-10-09 19:43:37 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 101
ERROR - 2025-10-09 19:44:00 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 110
ERROR - 2025-10-09 19:45:20 --> 404 Page Not Found: Boxito/principal
ERROR - 2025-10-09 19:45:45 --> Severity: Warning --> Undefined variable $nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 74
ERROR - 2025-10-09 19:45:45 --> Severity: Warning --> Undefined variable $correo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 75
ERROR - 2025-10-09 19:45:45 --> Severity: Warning --> Undefined variable $correo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 76
ERROR - 2025-10-09 19:46:40 --> Severity: Warning --> Undefined variable $nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 75
ERROR - 2025-10-09 19:46:40 --> Severity: Warning --> Undefined variable $correo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 76
ERROR - 2025-10-09 19:46:40 --> Severity: Warning --> Undefined variable $correo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 77
ERROR - 2025-10-09 19:47:42 --> Severity: Warning --> Undefined variable $nombre C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 86
ERROR - 2025-10-09 19:47:42 --> Severity: Warning --> Undefined variable $correo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 87
ERROR - 2025-10-09 19:47:42 --> Severity: Warning --> Undefined variable $correo C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 88
ERROR - 2025-10-09 21:06:28 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\welcome_message.php 3
ERROR - 2025-10-09 23:52:56 --> 404 Page Not Found: Boxito/principal
ERROR - 2025-10-09 23:53:01 --> 404 Page Not Found: Boxito/index
