<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-03 03:16:15 --> Severity: error --> Exception: C:\Users\karim\OneDrive\Escritorio\Laragon6\www\EMPRESAA\application\models/Pagina_model.php exists, but doesn't declare class Pagina_model C:\Users\karim\OneDrive\Escritorio\Laragon6\www\EMPRESAA\system\core\Loader.php 306
ERROR - 2025-10-03 03:25:18 --> Severity: Warning --> Undefined property: stdClass::$nombre_seccion C:\Users\karim\OneDrive\Escritorio\Laragon6\www\EMPRESAA\application\views\welcome_message.php 82
ERROR - 2025-10-03 21:59:20 --> 404 Page Not Found: Faviconico/index
