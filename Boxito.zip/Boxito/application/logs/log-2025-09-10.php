<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-10 18:44:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-09-10 19:04:06 --> Severity: error --> Exception: Unknown database 'empresaa' C:\Users\karim\OneDrive\Escritorio\Laragon6\www\EMPRESAA\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-09-10 19:53:31 --> 404 Page Not Found: Parisjpg/index
ERROR - 2025-09-10 19:53:31 --> 404 Page Not Found: Newyorkjpg/index
ERROR - 2025-09-10 19:53:32 --> 404 Page Not Found: Sanfranjpg/index
ERROR - 2025-09-10 19:53:32 --> 404 Page Not Found: W3images/map.jpg
ERROR - 2025-09-10 20:09:39 --> 404 Page Not Found: Parisjpg/index
ERROR - 2025-09-10 20:09:39 --> 404 Page Not Found: Newyorkjpg/index
ERROR - 2025-09-10 20:09:40 --> 404 Page Not Found: Sanfranjpg/index
ERROR - 2025-09-10 20:09:40 --> 404 Page Not Found: W3images/map.jpg
ERROR - 2025-09-10 20:14:11 --> 404 Page Not Found: Newyorkjpg/index
ERROR - 2025-09-10 20:14:11 --> 404 Page Not Found: Sanfranjpg/index
ERROR - 2025-09-10 20:14:11 --> 404 Page Not Found: W3images/map.jpg
ERROR - 2025-09-10 20:24:07 --> 404 Page Not Found: W3images/map.jpg
ERROR - 2025-09-10 20:25:09 --> 404 Page Not Found: W3images/map.jpg
