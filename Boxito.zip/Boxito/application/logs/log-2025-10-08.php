<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-08 19:18:39 --> Severity: Warning --> Undefined variable $idcatseccion C:\Users\karim\OneDrive\Escritorio\Laragon6\www\EMPRESAA\application\models\Pagina_model.php 21
ERROR - 2025-10-08 19:30:06 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_secciones_x_idseccion'., SQL state 37000 in SQLExecDirect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\EMPRESAA\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-08 19:30:06 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_secciones_x_idseccion'. - Invalid query: exec pa_consultar_secciones_x_idseccion @idseccion='1'
