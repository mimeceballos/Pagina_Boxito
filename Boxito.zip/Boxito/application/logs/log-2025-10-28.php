<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-28 00:34:09 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Cannot open database &quot;Boxito&quot; requested by the login. The login failed., SQL state 37000 in SQLConnect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-28 00:34:09 --> Unable to connect to the database
ERROR - 2025-10-28 00:34:09 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Cannot open database &quot;Boxito&quot; requested by the login. The login failed., SQL state 37000 in SQLConnect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-28 00:34:09 --> Unable to connect to the database
ERROR - 2025-10-28 00:35:58 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 00:49:13 --> 404 Page Not Found: Welcome/contactanos
ERROR - 2025-10-28 00:52:06 --> 404 Page Not Found: Welcome/contactanos
ERROR - 2025-10-28 00:52:09 --> 404 Page Not Found: Welcome/contactanos
ERROR - 2025-10-28 00:53:06 --> 404 Page Not Found: Welcome/contacto
ERROR - 2025-10-28 00:53:32 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 00:55:49 --> 404 Page Not Found: Welcome/contacto.php
ERROR - 2025-10-28 00:56:17 --> 404 Page Not Found: Welcome/index
ERROR - 2025-10-28 00:57:34 --> 404 Page Not Found: Welcome/contacto.php
ERROR - 2025-10-28 00:58:22 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 00:58:26 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 00:58:30 --> 404 Page Not Found: Welcome/ba%C3%B1os
ERROR - 2025-10-28 00:58:35 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 00:58:38 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 00:58:41 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 00:58:44 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 00:58:46 --> 404 Page Not Found: Welcome/ferreteria.php
ERROR - 2025-10-28 01:02:23 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:02:29 --> 404 Page Not Found: Welcome/ferreteria.php
ERROR - 2025-10-28 01:09:48 --> 404 Page Not Found: Welcome/ba%C3%B1os
ERROR - 2025-10-28 01:09:54 --> 404 Page Not Found: Welcome/ferreteria.php
ERROR - 2025-10-28 01:10:02 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:29:44 --> 404 Page Not Found: Welcome/contacto
ERROR - 2025-10-28 01:31:55 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:32:35 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:32:37 --> 404 Page Not Found: Welcome/contacto
ERROR - 2025-10-28 01:35:28 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:35:37 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:35:42 --> 404 Page Not Found: Welcome/ba%C3%B1os
ERROR - 2025-10-28 01:37:32 --> 404 Page Not Found: Welcome/ba%C3%B1os
ERROR - 2025-10-28 01:38:14 --> 404 Page Not Found: Welcome/ba%C3%B1os
ERROR - 2025-10-28 01:39:05 --> 404 Page Not Found: Welcome/ferreteria.php
ERROR - 2025-10-28 01:41:41 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:41:43 --> 404 Page Not Found: Welcome/ferreteria
ERROR - 2025-10-28 01:41:54 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:41:57 --> 404 Page Not Found: Welcome/ferreteria
ERROR - 2025-10-28 01:44:18 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:47:39 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:47:45 --> 404 Page Not Found: Welcome/ba%C3%B1o
ERROR - 2025-10-28 01:49:29 --> 404 Page Not Found: Welcome/ba%C3%B1o
ERROR - 2025-10-28 01:52:51 --> 404 Page Not Found: Welcome/ba%C3%B1o
ERROR - 2025-10-28 01:52:56 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:53:29 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:53:34 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:53:39 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:53:43 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 01:53:55 --> Severity: error --> Exception: Call to undefined method Pagina_model::consultar_baño() C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 30
ERROR - 2025-10-28 01:54:14 --> Severity: error --> Exception: Call to undefined method Pagina_model::consultar_baño() C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 30
ERROR - 2025-10-28 01:54:39 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 02:51:37 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 03:39:11 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'., SQL state S0022 in SQLExecDirect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-28 03:39:11 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'. - Invalid query: SELECT contenido FROM [Boxito].dbo.cat_contenido WHERE idcatseccion = 2
ERROR - 2025-10-28 03:39:19 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'., SQL state S0022 in SQLExecDirect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-28 03:39:19 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'. - Invalid query: SELECT contenido FROM [Boxito].dbo.cat_contenido WHERE idcatseccion = 1
ERROR - 2025-10-28 03:43:20 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'., SQL state S0022 in SQLExecDirect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-28 03:43:20 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'. - Invalid query: SELECT contenido FROM [Boxito].dbo.cat_contenido WHERE idcatseccion = 1
ERROR - 2025-10-28 03:44:07 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'., SQL state S0022 in SQLExecDirect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-28 03:44:07 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'. - Invalid query: SELECT contenido FROM [Boxito].dbo.cat_contenido WHERE idcatseccion = 1
ERROR - 2025-10-28 05:12:40 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'., SQL state S0022 in SQLExecDirect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-28 05:12:40 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'. - Invalid query: SELECT contenido FROM [Boxito].dbo.cat_contenido WHERE idcatseccion = 1
ERROR - 2025-10-28 05:12:41 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'., SQL state S0022 in SQLExecDirect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-28 05:12:41 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'. - Invalid query: SELECT contenido FROM [Boxito].dbo.cat_contenido WHERE idcatseccion = 1
ERROR - 2025-10-28 05:12:57 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'., SQL state S0022 in SQLExecDirect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-28 05:12:57 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'idcatseccion'. - Invalid query: SELECT contenido FROM [Boxito].dbo.cat_contenido WHERE idcatseccion = 1
ERROR - 2025-10-28 06:13:32 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 31
ERROR - 2025-10-28 06:13:38 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 58
ERROR - 2025-10-28 06:13:39 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:13:42 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 31
ERROR - 2025-10-28 06:15:21 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 29
ERROR - 2025-10-28 06:16:52 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 29
ERROR - 2025-10-28 06:19:43 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 29
ERROR - 2025-10-28 06:19:49 --> 404 Page Not Found: Welcome/aire
ERROR - 2025-10-28 06:20:37 --> 404 Page Not Found: Welcome/aire
ERROR - 2025-10-28 06:36:27 --> Severity: Warning --> Undefined variable $datos C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 29
ERROR - 2025-10-28 06:36:30 --> Severity: error --> Exception: Call to undefined method Pagina_model::buscar_productos() C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 54
ERROR - 2025-10-28 06:40:54 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'dbo.pa_buscar_producto'., SQL state 37000 in SQLExecDirect C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-28 06:40:54 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'dbo.pa_buscar_producto'. - Invalid query: EXEC [dbo].[pa_buscar_producto] @iddepartamento = 1
ERROR - 2025-10-28 06:41:38 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:46:13 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:47:55 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:49:06 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting "elseif" or "else" or "endif" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\departamentos\aire.php 25
ERROR - 2025-10-28 06:49:14 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting "elseif" or "else" or "endif" C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\views\departamentos\aire.php 25
ERROR - 2025-10-28 06:49:23 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:49:36 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:49:51 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:52:31 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:53:52 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:54:25 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 06:54:50 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:10:41 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:13:01 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:13:20 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:13:34 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:14:50 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:15:23 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:15:54 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:18:41 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:19:19 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:19:54 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:20:15 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:21:53 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:23:05 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:23:20 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:23:37 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:23:50 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:23:59 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:25:09 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:25:12 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:25:31 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:25:34 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:25:52 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:26:34 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:26:52 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:27:37 --> Severity: Compile Error --> Cannot redeclare Welcome::bano() C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 74
ERROR - 2025-10-28 07:27:58 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:28:19 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:29:29 --> Severity: Compile Error --> Cannot redeclare Welcome::piso() C:\Users\karim\OneDrive\Escritorio\Laragon6\www\Boxito\application\controllers\Welcome.php 88
ERROR - 2025-10-28 07:30:20 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:30:24 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:31:06 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:33:01 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:33:40 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:34:07 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:34:10 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:34:13 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:34:16 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:34:19 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:34:25 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:34:27 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:34:33 --> 404 Page Not Found: Welcome/assets
ERROR - 2025-10-28 07:35:46 --> 404 Page Not Found: Welcome/assets
