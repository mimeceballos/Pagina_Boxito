<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Pagina_model','mP');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	 //PRINCIPAL
	public function index(){
		$this->load->view('secciones/header');
		$this->load->view('welcome_message');
		$this->load->view('secciones/footer');
	}

	//QUIENES SOMOS
	public function nosotros() {
		$this->load->view('secciones/header');
		$this->load->view('nosotros/nosotros');
		$this->load->view('secciones/footer');
	}

	public function mision() {
		$this->load->view('secciones/header');
		$this->load->view('nosotros/mision');
		$this->load->view('secciones/footer');
	}

	public function vision() {
		$this->load->view('secciones/header');
		$this->load->view('nosotros/vision');
		$this->load->view('secciones/footer');
	}

	//DEPARTAMENTOS
	public function aire() {
		$datos["productos_aire"] = $this->mP->buscar_productos(1);
		$this->load->view('secciones/header');
		$this->load->view('departamentos/aire', $datos);
		$this->load->view('secciones/footer');
	}

	public function plomeria() {
		$datos["productos_plomeria"] = $this->mP->buscar_productos(2);
		$this->load->view('secciones/header');
		$this->load->view('departamentos/plomeria', $datos);
		$this->load->view('secciones/footer');
	}

	public function bano() {
		$datos["productos_bano"] = $this->mP->buscar_productos(3);
		$this->load->view('secciones/header');
		$this->load->view('departamentos/bano', $datos);
		$this->load->view('secciones/footer');
	}

	public function piso() {
		$datos["productos_piso"] = $this->mP->buscar_productos(4);
		$this->load->view('secciones/header');
		$this->load->view('departamentos/piso', $datos);
		$this->load->view('secciones/footer');
	}

	public function cocina() {
		$datos["productos_cocina"] = $this->mP->buscar_productos(5);
		$this->load->view('secciones/header');
		$this->load->view('departamentos/cocina', $datos);
		$this->load->view('secciones/footer');
	}

	public function hogar() {
		$datos["productos_hogar"] = $this->mP->buscar_productos(6);
		$this->load->view('secciones/header');
		$this->load->view('departamentos/hogar', $datos);
		$this->load->view('secciones/footer');
	}

	public function electricidad() {
		$datos["productos_electricidad"] = $this->mP->buscar_productos(7);
		$this->load->view('secciones/header');
		$this->load->view('departamentos/electricidad', $datos);
		$this->load->view('secciones/footer');
	}

	public function ferreteria() {
		$datos["productos_ferreteria"] = $this->mP->buscar_productos(8);
		$this->load->view('secciones/header');
		$this->load->view('departamentos/ferreteria', $datos);
		$this->load->view('secciones/footer');
	}


	public function oferta() {
		$this->load->view('secciones/header');
		$this->load->view('oferta');
		$this->load->view('secciones/footer');
	}

	
	public function contacto(){
		$this->load->view('secciones/header');
		$this->load->view('contacto');
		$this->load->view('secciones/footer');
	}

	/*public function nosotros() {
		$this->load->view('secciones/header');
		$this->load->view('nosotros');
		$this->load->view('secciones/footer');
	}*/


}