<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model { 
    /*Estructura de función para realizar consultas
    function consultar_aires($idcatseccion){
        $sql = "SELECT contenido FROM [Boxito].dbo.cat_contenido WHERE idcatseccion = 1";
        $query=$this->db->query($sql);
        if($query!=false){
            return $query->result();
        } else{
            return false;
        }
    }*/
}