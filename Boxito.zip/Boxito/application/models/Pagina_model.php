<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pagina_model extends CI_Model {
    
    function buscar_productos($iddepartamento) {
        $sql = "EXEC [dbo].[pa_buscar_productos] @iddepartamento = ?";
        $query = $this->db->query($sql, array($iddepartamento));
        
        if($query != false){
            return $query->result();
        } 
    }

}